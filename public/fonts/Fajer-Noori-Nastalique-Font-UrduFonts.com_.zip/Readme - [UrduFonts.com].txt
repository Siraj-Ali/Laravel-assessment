--------------------------------------------------------
Free Download Latest Unicode Urdu Fonts on UrduFonts.com
𝗪𝗲 𝗵𝗮𝘃𝗲 𝗰𝗼𝗺𝗽𝗹𝗲𝘁𝗲 𝗰𝗼𝗹𝗹𝗲𝗰𝘁𝗶𝗼𝗻 𝗼𝗳 𝗨𝗿𝗱𝘂 𝗙𝗼𝗻𝘁𝘀 𝗼𝗳 𝗮𝗹𝗹 𝗣𝗼𝗽𝘂𝗹𝗮𝗿 𝗦𝘁𝘆𝗹𝗲𝘀 & 𝗖𝗮𝘁𝗲𝗴𝗼𝗿𝗶𝗲𝘀
--------------------------------------------------------


𝐅𝐨𝐧𝐭 𝐂𝐚𝐭𝐞𝐠𝐨𝐫𝐢𝐞𝐬
--------------
Abstract Design
Arabic Face
Bold 
Calligraphic
Diwani
Handwriting
Kufic
Naskh
Nastaliq
Outline
Party
Quranic
Rounded
Ruqaa
Sqaure Kufic
Tech
Thin
Thuluth
Wide 


𝐅𝐨𝐧𝐭 𝐒𝐭𝐲𝐥𝐞𝐬
----------
Black
Calligraphy
Cartoon Style
Chalk Font
Chalk Writing
Circular
Condensed
Curly
Curve Fonts
Filled
Floral
Free Hand
Ink Style
Italic
Kufic
Lines
Modern 
Qalam Writing
Regular
Script
Shadow
Stroke
Urdu Font Family
Wide 



